const result = document.querySelector(".texte");
let button = document.querySelectorAll("#press");

button.forEach(function(eachbutton) {
     eachbutton.addEventListener = 
})

console.log('#texte');
