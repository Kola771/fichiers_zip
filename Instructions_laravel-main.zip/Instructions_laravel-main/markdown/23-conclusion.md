#### Pour finir

Vous avez maintenant les connaissances pour créer une application CRUD sécurisée avec laravel, l'écosystème est très vaste, de multiples resources existent pour approfondir vos connaissances.

Voici quelques liens qui vous aideront :  
- [laracasts](https://laracasts.com)
- [Le forum](https://laracasts.com/discuss)
- [le blog](https://blog.laravel.com)
- [laravel news](https://laravel-news.com)
- Des librairies : [spatie](https://spatie.be/open-source/packages?search=&sort=name)
