# 1er exercice : Le tout ensemble

Le temps est venu de mettre le tout en pratique.
- Modifiez Le contrôleur `ArticlesController` pour récupérer les articles avec leurs auteurs.
- Les articles doivent être triés par date descendante. 
- Modifiez la vue `articles` pour afficher les articles.
  - La vue devra afficher la liste des articles, uniquement le titre et le nom de l'auteur.
  - Créez un lien vers __un__ article. Servez-vous de la documentation pour créer ce lien dynamique. (On créera la vue plus tard)
  - Servez-vous du tag HTML `<article>` pour toutes les pages créées.
  - Ne vous occupez pas du CSS pour l'instant, on fera tout plus tard en nous servant des outils à notre disposition.
