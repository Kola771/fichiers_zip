# 2ème exercice : Route Model Binding 

- Modifiez l'application pour récupérer un article, son auteur et ses commentaires automatiquement
- Utilisez la propriété `$appends`
- Modifiez tous les fichiers nécessaires : `Article.php`, `ArticlesControlleur`.

Si tout est fait correctement, vous devriez pouvoir utiliser le Route Model Binding.
