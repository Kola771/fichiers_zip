# À propos du framework laravel
Au moment de l'écriture de ces lignes, le framework en est à la version 8 et est fait de 8 composants de symfony, 13 composants de diverses sources, et 22 composants écrits par Taylor Otwell, son créateur.  
Laravel est un framework PHP MVC qui permet de développer facilement et rapidement des applications web professionnelles.  
Ce framework est actuellement le plus utilisé au monde, sauf en France ou c'est symfony qui est majoritaire.
#### Facilité d'utilisation du framework
Ce framework est plus facile à 'prendre en main' que symfony, il est aussi plus permissif au niveau du code. Ce n'est pas une raison pour en profiter et écrire du code 'qui marche' sans y réfléchir plus que ça.  
La qualité du code ne vient pas d'un framework, mais du développeur.  
---
[La documentation](https://laravel.com/docs)
