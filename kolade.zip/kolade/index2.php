<?php
var_dump($_POST);
echo '<br><pre>';
var_dump($_FILES);
echo '</pre>';
if(isset($_FILES['file'])){
    $tmpName = $_FILES['file']['tmp_name'];
    $name = $_FILES['file']['name'];
    $size = $_FILES['file']['size'];
    $error = $_FILES['file']['error'];

    $tabExtension = explode('.', $name);
    $extension = strtolower(end($tabExtension));
    // Tableau des extensions que l'on accepte
    $extensions = ['jpg', 'png', 'jpeg', 'gif'];
    // Taille max que l'on accepte
    $maxSize = 400000;

    if(in_array($extension, $extensions) && $size <= $maxSize && $error == 0) {
        move_uploaded_file($tmpName, './upload2/'.$name);
        echo 'Bonne taille';
    }
    else {
        echo 'Taille elevée';
    }
}
?>