<?php
var_dump($_POST);
echo '<br><pre>';
var_dump($_FILES);
echo '</pre>';
if(isset($_FILES['file'])){
    $tmpName = $_FILES['file']['tmp_name'];
    $name = $_FILES['file']['name'];
    $size = $_FILES['file']['size'];
    $error = $_FILES['file']['error'];

    move_uploaded_file($tmpName, './upload/'.$name);
}
?>