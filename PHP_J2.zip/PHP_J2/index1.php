<!DOCTYPE html>
<html lang="fr-FR">
  <head>
    <meta charset="UTF-8">
    <title>Hey</title>
  </head>
  <body>
    <h1>Salut !</h1>
  
    <?php require './index.php'; ?>

    <?php
    $lettre = range("a", "z");
    echo array_rand($lettre);
    $key = array_rand($lettre);
    $key2 = array_rand($lettre);
    echo '<br>' .strtoupper($lettre[$key].$lettre[$key2]);
    // var_dump ($lettre);

    echo('<br> (strlen) ');
    $mystr = 'Highfive';
    echo strlen($mystr);
    
    echo('<br> (strpos) ');
    echo strpos($mystr, 'g');
    
    echo str_replace($mystr, "kola", "Hello $mystr");
    
    echo('<br> (htmlspecialchars) ');
    $string = "<h2>kola</h2>";
    echo htmlspecialchars($string, ENT_QUOTES);
    
    echo('<br> (explode) ');
    print_r(explode(' ', $mystr));

    $arr = ['lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi', 'dimanche'];
    $key = array_rand($arr);
    $key2 = array_rand($arr);
    echo '<br>' .strtoupper($arr[$key].$arr[$key2]);
    
    echo '<br>' . rand();
    
    $arr = ['lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi', 'dimanche'];
    echo ('<br>' .count($arr));
    // echo '<pre>' ;
    // var_dump($_SERVER);
    // echo '</pre>' ;

    // echo '<br>' ;
    // var_dump($_REQUEST);

    // echo '<br>' ;
    // var_dump($_POST);
    ?>

    <form action="/PHP_J2/index1.php" method="post">
      <input type="text" name="fname" placeholder="prenom">
      <input type="text" name="lname" placeholder="nom">
      <input type="number" name="age" placeholder="age">
      <input type="submit" value="send">
      <input type="reset" value="annuler">
    </form>

    <?php
    echo '<pre>';
    echo ($_POST["fname"]);
    echo '</pre>';
    ?>
  </body>
</html>