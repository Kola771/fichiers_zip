<?php
            $dat = date('H : i : s');
            // if (isset($_POST['fname']) && isset($_POST['lname'])) {
            //     echo $_POST['fname'];
            //     echo '<br />';
            //     echo $_POST['lname'];
            // }
            $rand = rand(1, 100000);
            $rande = rand(1, 100000);
            $lettre = range("a", "z");
            $key = array_rand($lettre);
            $key2 = array_rand($lettre);
            $_id = $rande. "-" .strtoupper($lettre[$key].$lettre[$key2]). "-" .$rand;

            $nom = $_POST['lname'];
            $prenom = $_POST['fname'];
            
?>

        <p>
            <?php 
            
            if ($nom === "aboudou" || $nom === "Aboudou" || $nom === "ABOUDOU") {
                echo "[Session Admin]<br>";
                echo "<a href='$prenom' class='$prenom'>Vos paramètres</a>";
                }
            else {
                echo $nom. "." .$prenom. "<br>";
                echo "<a href='$prenom.html' class='$prenom'>Modifier votre profil</a>";
                } 
                
            ?>
        </p>

        <div>
            { <?php echo($_id); ?> }
        </div>

        <div>
            <?php echo("Vous vous etes connecté à " .$dat); ?>
        </div>