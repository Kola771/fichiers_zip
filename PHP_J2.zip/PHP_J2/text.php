<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forumulaire</title>
    <style>
        body {
            background-color: rgb(27, 26, 26);
            color: white;
            margin: 0;
        }
        p {
            font-size: 18px;
            margin: 0;
            color: #f50;
            text-transform: capitalize;
        }
        p>a {
            font-size: 15px;
            text-transform: none;
        }
        div:nth-of-type(1) > div:first-child {
            font-size: 15px;
            margin-block: 10px;
        }
        .grande-div  {
            font-size: 18px;
        }
        .grande-div > div:last-child {
            text-transform: uppercase;
            color:red;
            font-weight: bold;
        }
       
    </style>
</head>
<body>
        
        <div>
        <?php require './generic_functions.php'; ?>
       </div>
       
</body>
</html>