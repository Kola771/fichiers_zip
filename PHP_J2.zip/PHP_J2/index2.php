<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forumulaire</title>
    <style>
        body {
            background-color: rgb(27, 26, 26);
            margin: 0;
        }

        form {
            margin: 15% auto;
            max-width: 50%;
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 1em;
            border: 2px solid rgb(11, 68, 3);
            padding: 2em;
        }

        form>div {
            flex-basis: 100%;
            display: flex;
            flex-wrap: wrap;
            color: white;
        }

        form>div:nth-of-type(1) {
            gap: 1em;
        }

        form>div:nth-of-type(1)>input {
            flex-basis: 100%;
            padding: 1em;
            outline: none;
            border: none;
            border-bottom: 1px solid;
            background-color: rgb(27, 26, 26);
            color: white;
        }

        form>div:nth-of-type(2)>button {
            flex-basis: 50%;
            padding: 1em;
            border: none;
            color: white;
        }

        form>div:nth-of-type(2)>button:nth-of-type(1) {
            background-color: rgb(68, 16, 3);
        }

        form>div:nth-of-type(2)>button:nth-of-type(2) {
            background-color: rgb(11, 68, 3);
        }
    </style>
</head>

<body>
    <form action="text.php" method="post">
        <div>
            <label for="#">Le nom de votre robot</label>
            <input type="text" name="lname" placeholder="XX-9999">
            <label for="#">Moralité de votre robot</label>
            <input type="text" name="moralite" placeholder="Moralité">
        </div>
        <div>
            <button type="reset">Annuler</button>
            <button type="submit">Valider</button>
        </div>
    </form>
</body>

</html>