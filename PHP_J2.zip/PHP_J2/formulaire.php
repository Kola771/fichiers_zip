<?php

$fname = $lname = $age = $pass = "";
$fnames = $lnames = $ages = $pwd = "";

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fnames = $_POST['fname'];
    $lnames = $_POST['lname'];
    $ages = $_POST['age'];
    $pwd = $_POST['pwd'];
    
    if(empty($_POST['fname'])) {
        $fname = 'Veuillez renseigner votre prénom';
    }
    if(empty($_POST['lname'])) {
        $lname = 'Veuillez renseigner votre nom';
    }
    if(empty($_POST['age'])) {
        $age = 'Veuillez renseigner votre age';
    }
    if(empty($_POST['pwd'])) {
        $pass = 'Veuillez renseigner votre password';
    }

    if(!empty($fnames) && !empty($lnames) && !empty($ages) && !empty($pwd)) {
        $fnames = $lnames = $ages = $pwd = "";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="formulaire.css">
    <title>Formulaire</title>
</head>
<body>
    <div class="container">
        <h2>Formulaire de validation</h2>
        <p>* Champ obligatoire</p>
        <form action="formulaire.php" method="post">
            <div>
                <input type="text" name="fname" placeholder="Your firstname" value="<?= $fnames; ?>" >
                <span class="smscolor"><?= $fname ?></span>
            </div>
            <div>
                <input type="text" name="lname" placeholder="Your lastname" value="<?= $lnames; ?>">
                <span class="smscolor"><?= $lname ?></span>
            </div>
            <div>
                <input type="number" name="age" placeholder="Your age">
                <span class="smscolor" value="<?= $ages; ?>"><?= $age ?></span>
            </div>
            <div>
                <input type="password" name="pwd" placeholder="Your password" value="<?= $pwd; ?>">
                <span class="smscolor"><?= $pass ?></span>
            </div>
            <div>
                <button type="submit">Valider</button>
                <button type="reset">Annuler</button>
            </div>
        </form>
           <div class="php">
            <?php
                echo $fnames. '<br>';
                echo $lnames. '<br>';
                echo $ages. '<br>';
                echo $pwd. '<br>';
            ?>
           </div>
    </div>
    <pre style="color:white">
        <?php
                    $str = "pig dig dog kig";
                    echo $str . "<br>";
                    echo preg_replace("/.o/im", "**", $str) . "<br>";
                    echo preg_replace("/dig|dog/im", "--", $str) . "<br>";
                    echo preg_replace("/.ig$/im", "**", $str) . "<br>";
                    echo preg_replace("/.ig\b/im", "**", $str) . "<br>";
        ?>
    </pre>
</body>
</html>