<footer>
    <p>FOOTER</p>
</footer>
</body>
</html>