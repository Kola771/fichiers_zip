<?php


class Home {
    public function index() {
        echo "Hello depuis la méthode index() de la classe Home()";
    }

    public function addUsers() {
        echo "Hello depuis la méthode addUsers() de la classe Home()";
    }
}