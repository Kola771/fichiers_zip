<?php


class Posts {
    public function index() {
        echo "Hello depuis la méthode index() de la classe Posts()";
    }

    public function addNew() {
        echo "Hello depuis la méthode addNew() de la classe Posts()";
    }
}