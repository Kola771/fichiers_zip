async function getUser(username) {
	
}

export default getUser;
