<?php
    require "./header.php";
?>
    <h1>Page private</h1>
    <p>Cette page est privée.</p>
    <p>Vous ne pouvez la voir que si vous êtes connecté.</p>

    <p><a href="./public.php">Retournez à la page publique</a></p>

<?php
    require "./header.php";
?>