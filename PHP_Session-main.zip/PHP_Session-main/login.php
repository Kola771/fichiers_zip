<?php

session_start(); // récupérer l'ancienne session
header("Location: ./public.php");