# L'héritage

- Créer une `class User`, qui a pour propriétés qui possède une méthode `fullName`.
- La méthode `fullName` prend deux arguments : `name` et `firstName` et retourne la concaténation des deux. 
- Créer une `class Admin` qui hérite de la `class User` et qui ajoute une méthode `canEditArticles`. 
- Cette méthode devra retourner `true`.
- Console loguer les instances de ces classes et analyser les différences.
