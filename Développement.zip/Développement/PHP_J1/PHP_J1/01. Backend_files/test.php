<?php
$msg = "Salut";
$msg = "Yo";
echo($msg);
?>