

console.log(document);