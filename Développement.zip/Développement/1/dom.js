
let divElement = document.createElement("div");

divElement.setAttribute("id", "demo");

divElement.setAttribute("class", "big normal");

divElement.innerHTML = "Lorem ipsum";

// divElement.innerText = "Lorem ipsum";

// divElement.textContent = "Lorem ipsum";

document.body.append(divElement);

