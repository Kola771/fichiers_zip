# La composition

On a vu qu'un objet peut être composé en partie d'un autre objet.

- Dans notre `class User`, ajoutez un propriété. `age`.
- Cette propriété sera un objet qui possède ses propres propriétés.
- On ne peut en effet pas être agé de -10ans, et pas encore jusqu'à 150 ans...
- L'âge doit être un nombre, pas une 'string'.
- Console loguer le résultat.
