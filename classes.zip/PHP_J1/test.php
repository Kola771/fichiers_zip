<?php
$msg = "Salut";
$msg = "Yo";
echo(" msg $msg ---- <br>");
$msg1 = "Salut";
$msg2 = &$msg1;
echo(" Msg2 $msg2 ---- <br>");

function increment(&$x) {
    ++$x;
}

$number = 1;
increment($number);
echo(" Incérementation $number ---- <br>");

$place = 'la planète';
$msge = 'Salut ' . $place;
echo(" Concatenation avec les guillemets simples $msge ---- <br>");

$place = 'la planète';
$msg = "Salut $place";
echo(" Conacaténation  avec les guillemets doubles $msg ---- <br>");

$x = 12;
$y = 45.263;
echo(" x =  $x  et y =  $y  ---- <br>");

$isUserAnonymous = false;

if (!$isUserAnonymous) {
    echo('Test booléen ---- <br>');
}

$texts = ['Salut', 'Yo', 'Hey'];
echo("Tableau index 0 < $texts[0] > ---- <br>");

$values = [
    'vegetable' => 'Échalote',
    'fruit' => 'Fraise'
];

$x = $values['vegetable'];

echo("Autre méthode pour les tableaux, index 0 < $x > ---- <br>");

$b = (int) '1'; 
$c = $b + 1; // 1
echo("$c ---- <br>");


$msg = 'Salut';
if ($msg === 'Salut') {
    echo("Comparaisons et condition (if) < $msg > ---- <br>");
}

$x = 0;
switch ($x) {
    case 0:
        echo('Comparaisons et condition (Switch) Salut ---- <br>');
        break;
    case 1:
        echo('Comparaisons et condition (Switch) Yo ---- <br>');
        break;
    default:
        echo('Comparaisons et condition (Switch) Hey ---- <br>');
}

$i = 1;

while ($i < 4) {
    echo ("Boucle While $i ---- <br>");
    ++$i;
}

$values = ['A', 'B', 'C', 'D'];

for ($i = 0, $max = count($values); $i < $max; ++$i) {
    echo ("Boucle For $values[$i] ---- <br>");
}

$values = [
    'msg' => 'Salut',
    'name' => 'Jacques',
    'age' => 45,
    'city' => 'Rennes',
];

foreach ($values as $key => $value) {
    echo("Clé : $key <br/>");
    echo("Valeur : $value <br/>");
}

function mutiply($x, $y) {
    return $x + $y;
}

echo mutiply(5, "7");

function addExclamationToMessage(string $message): string {
    return $message . ' !';
}
echo addExclamationToMessage("salut");

$vaml = [
    'name' => 'Jacques',
    'age' => 45,
    'city' => 'Rennes',
];
function getNameFromUser(array $user): ?string {
    if (isset($user['name']) && is_string($user['name'])) {
        return $user['name'];
    }

    return null;
}
echo getNameFromUser($vaml);

function appendPunctuation(string $str, string $punctuation = '.'): string {
    return $str . $punctuation;
}

echo appendPunctuation('<br> ----- Salut');


class User
{
    private string $firstName;
    private string $lastName;
    private int $age;

    public function __construct(string $firstName, string $lastName, int $age)
    {
        $this->firstName = $firstName;
        $this->lastName = $lastName;
        $this->age = $age;
    }

    public function getFirstName(): string
    {
        return $this->firstName;
    }

    public function getLastName(): string
    {
        return $this->lastName;
    }

    public function getAge(): int
    {
        return $this->age;
    }

    public function getFullName(): string
    {
        return $this->firstName . ' ' . $this->lastName;
    }

    public function sayMessage(string $message): void
    {
        echo $message;
    }
}
$user = new User('Magali', 'Dupont', 22);

echo ("<br> Classe " .$user->getFullName());
echo ($user->sayMessage("<br> Bonjour à tous"));

function getCurrentDate(): string {
    return date('d m Y');
}

$lettre = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
$longtab = count($lettre);
echo($longtab);
function entiern($lettre, int $max, int $min, $longtab) {
    echo strtoupper("<br>Lettre aleatoire: " .$lettre[rand($longtab, $max)].$lettre[rand($longtab, $max)]. "-" .rand($max, $min));
}
entiern($lettre, 0, 151000, $longtab);
?>

<!DOCTYPE html>
<html lang="fr-FR">
  <head>
    <meta charset="UTF-8">
    <title>Hello</title>
  </head>
  <body>
    <h1>Nous sommes le <?php echo getCurrentDate(); ?></h1>

    <script>
        let variable = (max, min) => parseInt(Math.random(max) * (max-min) + 1);
        console.log(variable(15000, 5));

        let lettre = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];

        let variables = (array, min, x, y) => (array[parseInt(Math.random(array.length) * 
        (array.length-min) + 1)]
         + array[parseInt(Math.random(array.length) * 
         (array.length-min) + 1)])
         .toUpperCase() + '-' + parseInt(Math.random(x) * (x-y) + 1);
        console.log(variables(lettre, 0, 15000, 0));
    </script>
  </body>
</html>