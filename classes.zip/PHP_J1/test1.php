<?php
$max = 0;
$min = 9999;
$lettre = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
$longtab = count($lettre);
function aleatoire($lettre, int $max, int $min, $longtab) {
    return strtoupper($lettre[rand(($longtab-1), $max)].$lettre[rand(($longtab-1), $max)]. "-" .rand($max, $min));
}

$affichage = aleatoire($lettre, $max, $min, $longtab);

function affichaDate() {
    return date('d m Y');
}

function affichaHeure() {
    return date('H:i:s');
}

function paire(int $x, int $y) {
    $nbre = rand($x, $y);
    // var_dump(fmod($nbre, 2)); pour connaitre le type d'un élément

    if (((int) fmod($nbre, 2)!== 0)) {
        return ("J'ai choisi le nombre " .$nbre. ". C'est un nombre impair."); 
    }
    else {
        return ("J'ai choisi le nombre " .$nbre. ". C'est un nombre pair.");  
    }
}

?>

<!DOCTYPE html>
<html lang="fr-FR">
  <head>
    <meta charset="UTF-8">
    <title>Exo</title>
  </head>
  <body>
      <p><?php echo("Salut, humain. Je suis " .$affichage) ?></p>
    <div>
        <h2>Bonus 1</h2>
        <p><?php echo("Nous sommes le " .affichaDate(). ", il est " .affichaHeure()) ?></p>
    </div>
    <div>
        <h2>Bonus 2</h2>
        <p><?php echo(paire(1, 10)) ?></p>
    </div>
    <div>
        <h2>Bonus 3</h2>
        <p><?php echo ("Je m'appelle ".strrev($affichage).". Ah Ah Ah") ?></p>
    </div>
  </body>
</html>