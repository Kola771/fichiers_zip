<?php
            $rand = rand(1, 10000);
            $lettre = range("A", "Z");
            $key = array_rand($lettre);
            $key2 = array_rand($lettre);
            $_id = ($lettre[$key].$lettre[$key2]). "-" .$rand;

            $tab = ['joyeux', 'généreux', 'sinistre', 'prétencieux', 'violent', 'réglo', 'choyeux', 'diabolique'];

            $cle = array_rand($tab);
            $_moral = $tab[$cle];

            $nom = $_POST['lname'];
            $moralite = $_POST['moralite'];
            $_dia = " Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique quo omnis asperiores inventore velit, quasi atque provident consectetur quibusdam suscipit sit repellendus blanditiis? Suscipit omnis fuga quisquam accusamus nostrum impedit?";

            
            if (!empty($nom) && !empty($moralite)) {
                echo "<p> $nom </p>";
                echo "<div> $moralite </div>";
                if ($moralite === 'diabolique') {
                    echo "<div class='grande-div'> 
                    <div>$_dia</div>
                    <div>$_dia</div>
                    <div>Mon robot est un dibolique monstre</div>
                    </div>";
                }
            }
             else{
                echo "<p> $_id </p>";
                echo "<div> Votre robot est '$_moral' </div>";
                if ($_moral === 'diabolique') {
                    echo "<div class='grande-div'> 
                    <div>$_dia</div>
                    <div>$_dia</div>
                    <div>Mon robot est un dibolique monstre</div>
                    </div>";
                }
            } 
            date_default_timezone_set('Africa/Porto-Novo');
            echo date("H:i:s");
 ?>


       