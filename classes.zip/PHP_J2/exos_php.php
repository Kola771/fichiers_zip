<?php
$phrases = "Bonjour kola anti-constitutionnellement";
function firstUppercase($phrase) {
    return $dollar = ucwords($phrase, " ");
} 
print_r(firstUppercase($phrases));

function longestWord($phrase) {
     $dollar = explode(" ", $phrase);
     $counter = count($dollar);
     $taille = 0;
     for ($i=0; $i < $counter ; $i++) { 
         $long = strlen($dollar[$i]);
        if($taille < $long) {
            $taille = $long;
        }
     }
     return $taille;
}
echo '<br>'.longestWord($phrases) . '<br>';

$tableau = [1, 2, 3, 4, 5, 6];
function largestnumber($arr) {
    return max($arr);
} 
echo 'Le plus grand nombre dans le tableau est: ' .largestnumber($tableau) . '<br>';

function confirmEnd(string $string, string $end) {
    if(str_ends_with($string, $end)) {
        echo "Vrai <br>";
    }
    else {
        echo "Faux <br>";
    }
} 
confirmEnd("Bonjour", "our");

function caracter($str, $nombre) {
    $spl = str_split($str, 1);
    $tab = [];
    for ($i=0, $max = count($spl); $i < $max ; $i++) { 
        if($i < $nombre) {
            array_push($tab, $spl[$i]);
        } else {
            array_push($tab, ".");
        }
    }
    return $tab;
}
$court = "Bonjour à tous !";
echo "<pre>";
print_r(caracter($court, 5));
echo "</pre>";

    $num = [1, 3, 5, 8, 9, 10];

    $filter = array_filter($num, function($el) {
        return $el%2 === 0;
    });

    echo "<pre>";
    print_r($filter);
    echo "</pre>";

    $mot = "reve";
        function repeter(string $str, int $num) {
            $dollar = str_repeat($str, $num);
            return $dollar;
        }
    echo repeter($mot, 5) . "<br>";

    function factoriel(int $number):int {
        $tab = 1;
        for ($i = 1; $i <= $number; $i++) {
          $tab = $tab * $i;
        }
        return $tab;
      }
      echo factoriel(5) . "<br>";


      $array3 = [1, 2, 3];
      $array4 = [4, 5];
    //   $newArray = [4, 5];
    //   array_splice($newArray, 1, 0, $array3);
    //   echo var_dump($newArray);
      function frankenSplice($arr1, $arr2, $index) {
        $new = $arr2;
        array_splice($new, $index, 0, $arr1);
        return $new;
      }
    echo "<pre>";
    print_r(frankenSplice($array3, $array4, 1));
    echo "</pre>";

    $array3 = [1, 2, 3];
    $array4 = [4, 5, 50, 205];
    function cmp($a, $b)
    {
        if ($a == $b) {
            return 0;
        }
        return ($a < $b) ? -1 : 1;
    }
      function frankenSplice1($arr1, $arr2) {
        $new = $arr2;
        array_push($new, $arr1);
        usort($new, "cmp");
        for ($i=0; $i < count($new) ; $i++) { 
            if ($new[$i] === $arr1) {
                echo $i;
            }
        }
        }
      
    
    echo "<pre> L'index du nombre est: '";
    print_r(frankenSplice1(100, $array4));
    echo "'</pre>";

    
    $array = ['Hello', 'hello'];
    function verifie($table) {
        $search = "/$table[1]/im";
        $k = preg_match_all($search, $table[0]);
        if ($k === 1) {
            echo "true";
        } elseif($k === 0) {
            echo "false";
        }
    }

    verifie($array);
  
?>

