<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forumulaire</title>
    <style>
        body {
            background-color: rgb(27, 26, 26);
            color: white;
            margin: 0;
        }
        p {
            font-size: 20px;
            margin: 0;
            color: #f50;
            text-transform: capitalize;
        }
        p>a {
            font-size: 15px;
            text-transform: none;
        }
        div:nth-of-type(1) {
            font-size: 15px;
            margin-block: 10px;
        }
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: .5em;
            border-bottom: 2px solid white;
        }
        header > nav > ul {
            display: flex;
            gap: 1em;
            list-style: none;
            padding: 0;
        }
        header > nav > ul > li > a {
            text-decoration: none;
            font-size: 20px;
        }
    </style>
</head>
<body>
        
    <header>
        <div>
        <?php require './return.php'; ?>
       </div>
       <nav>
        <ul>
            <li><a href="#">Home</a></li>
            <li><a href="#">Contact</a></li>
            <li><a href="#">A propos</a></li>
            <li><a href="#">Sign up</a></li>
            <li><a href="#">Log in</a></li>
        </ul>
    </nav>
    </header>
</body>
</html>