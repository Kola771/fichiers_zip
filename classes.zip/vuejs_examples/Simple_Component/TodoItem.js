export default {
    props: {
        todo: Object
    },
    template: /*html*/`
    <li>{{ todo.text }}</li>
    `
}