
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Envoi images</title>
    <style>
        body {
            background-color: #151516;
            color:white;
        }
        div, form {
            margin: 0 auto;
            max-width: 80%;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 1em;
        }
        form {
            align-items:center;
            border: 2px solid white;
            margin: 15px auto;
            padding: 1em;
        }
        form>input {
            border: 2px solid white;
            flex-basis:73%;
            padding: .5em;
        }
        form>h2 {
            color:#f50;
            flex-basis:100%;
        }
        form>button {
            flex-basis:80%;
            padding: .8em;
            border:none;
            background-color: #f50;
            color:white;
        }
        figure {
            border: 2px solid white;
            border-radius: 1em;
            padding: .5em;
            flex-basis:20%;
            margin:0;
        }
        figure>img {
            border-radius: 1em;
            width:100%;
            height:80%;
        }
    </style>
</head>
<body>
    <form action="uniqimg.php" method="post" enctype="multipart/form-data">
        <h2>Ajouter une image sur votre page</h2>
        <label for="file">Fichier</label>
        <input type="file" name="file" required>
        <button type="submit">Enregistrer</button>
        
    </form><br>
    <?php
    require './index3.php';
    ?>
    <div>
    <?php
    $req = $db->query('SELECT name FROM file');
    while($data = $req->fetch())
    {
        echo "<figure>
                <img src='./upload3/".$data['name']."'>
                <figcaption>
                Images via bdd
                </figcaption>
            </figure>";
    }
    ?>
    </div>
    
</body>
</html>