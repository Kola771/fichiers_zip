

// let login = document.getElementById("login");

// let ul2 = document.querySelector(".ul2_header");

// let ul21 = document.querySelectorAll(".ul2_header>li");

let figure = document.querySelectorAll("figure");

let p = document.getElementById("paragraphe");

// let sign = document.querySelector(".sign");

// let conn = document.querySelector(".conn");

// let form1 = document.querySelector(".form_1");

// let form2 = document.querySelector(".form_2");

let main = document.querySelector(".main_pre_accueil"); 

let demo = "Cette plateforme vous donne accès à certaines oeuvres inexplorées. Des histoires inédites, remplies de fortes sensations. Des histoires de roman pour les amoureux, d'aventure et autres...";
let affichage = document.querySelector(".affichage");

let tab = demo.split(" ");

let accueil = document.querySelector(".accueil");

console.log(affichage);

let z = 0;
let r = 0;
let compteur;

document.addEventListener("DOMContentLoaded", function () {
   compteur = setInterval(function() {
     affichage.innerHTML += tab[r] + " ";
     r++;
   if(r === tab.length) {
    clearInterval(compteur)
    affichage.style = "text-align: center; margin-bottom: 15px"
   }
  }, 1000/4);

  document.addEventListener("click", function (e) {

    if (e.target.className === "figure1") {
      p.innerHTML = "Vous devez préalablement avoir un compte pour lire cette oeuvre. Dans le cas échéant, veuillez bien vous inscrire.";
      p.style = "background-color: rgba(204, 240, 231, 0.87); padding: .5em; color: black";
    }

    if (e.target.className === "img") {
      p.innerHTML = "Vous devez préalablement avoir un compte pour lire cette oeuvre. Dans le cas échéant, veuillez bien vous inscrire.";
      p.style = "background-color: rgba(204, 240, 231, 0.87); padding: .5em; color: black";
    }

    if (e.target.className === "class_a_figure") {
      p.innerHTML = "Vous devez préalablement avoir un compte pour lire cette oeuvre. Dans le cas échéant, veuillez bien vous inscrire.";
      p.style = "background-color: rgba(204, 240, 231, 0.87); padding: .5em; color: black";
    }

  })

  // login.addEventListener('click', function (e) {
  //   e.preventDefault();
  //   switch (z) {
  //     case 0:
  //       ul2.style = "display: block";
  //       ul21.forEach((el, i) => el.style = "display:block");
  //       z++;
  //       break;
  //     case 1:
  //       ul2.style = "display: none";
  //       ul21.forEach((el, i) => el.style = "display: none");
  //       z = 0;
  //       break;
  //   }
  // })

  // sign.addEventListener('click', function(e) {
  //   e.preventDefault();
  //   main.style = "display:none";
  //   form2.style= "display: block";
  //   form1.style= "display: none";
  // });

  // conn.addEventListener('click', function(e) {
  //   e.preventDefault();
  //   main.style = "display:none";
  //   form1.style= "display: block";
  //   form2.style= "display: none";
  // });
  
  accueil.addEventListener('click', function(e) {
    e.preventDefault();
    main.style = "display:block";
    // form2.style= "display: none";
    // form1.style= "display: none";
    p.style = "display:none;";
  });
})

