
let livres = document.querySelector(".livre");

let livre = document.querySelectorAll(".livres");

let manga = document.querySelector(".manga");

let mangas = document.querySelectorAll(".mangas");

let bd = document.querySelector(".bd");

let comics = document.querySelectorAll(".comics");

let tous = document.querySelector(".tous");

let tout = document.querySelectorAll(".tout");

let icon = document.querySelector(".icon");

let icon1 = document.querySelector(".icon1");

let closes = document.querySelector(".close")

let p = document.querySelector(".fixed > section > .grande_div_section > .article > p");

let grande_div_section = document.querySelector(".grande_div_section");

let deconnexion = document.getElementById("deconnexion");

let li = document.querySelectorAll(".class");

let ul = document.querySelectorAll(".topul");

let h2 = document.querySelector("#div_section > h2");

let demo = "Livres - Bandes dessinées - Mangas";

let tab = demo.split(" ");

let search = document.querySelector('.search');

let closet = document.querySelector('.closes');

let recherche = document.getElementById('recherche');

let x = 0;
let y = 0;
let z = 0;
let t = 0;
let r = 0;
let compteur, demarrage;

let create_grand = document.createElement('div');
create_grand.setAttribute('class', 'grand');

let create_parent = document.createElement('div');
create_parent.setAttribute('class', 'parent');

create_grand.append(create_parent);

let myFunc = (num) => {
    let creer;
    for (let i = 0; i < num; i++) {
        creer = document.createElement('div');
        creer.setAttribute('class', 'loader' +`${i+1}`);
        create_parent.append(creer);
    }
    return creer;
}

myFunc(3);

document.body.append(create_grand);

document.addEventListener("DOMContentLoaded", function () {

    document.querySelector('.grand').style = 'display:block';
    demarrage = setInterval(function () {
        document.querySelector('.grand').style = 'display:none';
        clearInterval(demarrage);
    }, 8000)

    search.addEventListener('click', function () {
        recherche.style = "display: block";
    })

    closet.addEventListener('click', function () {
        recherche.style = "display: none";
    })

    compteur = setInterval(function () {
        h2.innerHTML += tab[r] + " ";
        r++;
        if (r === tab.length) {
            clearInterval(compteur);
        }
    }, 1000);

    document.addEventListener('click', (e) => {

        if (e.target.className === "livre") {
            livres.style = "background-color: #04042c";
            manga.style = "background-color: green";
            bd.style = "background-color: green";
            tous.style = "background-color: green";
            mangas.forEach((el, i) => el.style = "display: none");
            comics.forEach((el, i) => el.style = "display: none");
            livre.forEach((el, i) => el.style = "display: block");
        }

        if (e.target.className === "manga") {
            manga.style = "background-color: #04042c";
            livres.style = "background-color: green";
            bd.style = "background-color: green";
            tous.style = "background-color: green";
            livre.forEach((el, i) => el.style = "display: none");
            comics.forEach((el, i) => el.style = "display: none");
            mangas.forEach((el, i) => el.style = "display: block");
        }

        if (e.target.className === "bd") {
            bd.style = "background-color: #04042c";
            manga.style = "background-color: green";
            livres.style = "background-color: green";
            tous.style = "background-color: green";
            livre.forEach((el, i) => el.style = "display: none");
            mangas.forEach((el, i) => el.style = "display: none");
            comics.forEach((el, i) => el.style = "display: block");
        }

        if (e.target.className === "tous") {
            tous.style = "background-color: #04042c";
            bd.style = "background-color: green";
            manga.style = "background-color: green";
            livres.style = "background-color: green";
            tout.forEach((el, i) => el.style = "display: block");
        }

        if (e.target.className === "class_a") {
            switch (t) {
                case 0:
                    e.target.parentElement.childNodes[2].style = "display: block";
                    t++;
                    break;
                case 1:
                    e.target.parentElement.childNodes[2].style = "display: none";
                    document.querySelectorAll(".topul").forEach((el) => el.style = "display: none");
                    t = 0;
                    break;
            }
        }
    })

    icon1.addEventListener("click", function (e) {
        e.preventDefault()
        let x = document.getElementById("myTopnav");
        if (x.className === "topnav") {
            x.className += " responsive";
            h2.style = "opacity: 1"
        } else {
            x.className = "topnav";
            h2.style = "opacity: .8"
        }
    })

    icon.addEventListener("click", function (e) {
        e.preventDefault()
        let fixed = document.querySelector(".fixed");
        fixed.style = "display:block; width:50%";
        closes.style = "display:block";
        h2.style = "opacity: 1";
    })

    closes.addEventListener("click", function (e) {
        e.preventDefault()
        let fixed = document.querySelector(".fixed");
        fixed.style = "display:none";
        closes.style = "display:none";
        h2.style = "opacity: .8"
    })

    let vues = document.getElementsByClassName("vues");
    let i;

    for (i = 0; i < vues.length; i++) {
        vues[i].addEventListener("click", function () {
            this.classList.toggle("active");
            let button = this.nextElementSibling;
            if (button.style.display === "block") {
                button.style.display = "none";
            } else {
                button.style.display = "block";
            }
        });
    }

    let vue = document.getElementsByClassName("vue");

    for (i = 0; i < vue.length; i++) {
        vue[i].addEventListener("click", function () {
            this.classList.toggle("active");
            let button = this.nextElementSibling;
            if (button.style.display === "block") {
                button.style.display = "none";
            } else {
                button.style.display = "block";
            }
        });
    }


})