# Instructions

## Objectifs
Réaliser une partie d'un site marchand en matériel informatique / électronique.
La maquette est volontairement très proche des sites de ce type en ligne actuellement.
Le contenu de la fiche du produit présentée a été copié depuis un site existant.

Cet exercice comporte deux parties:
- La partie front qui comprend une page produit du site marchand.
- La partie back-office / administration du site comprend trois pages:
	- La page de gestion des produits
	- La page correspondant à la fiche produit du front
	- La page de création d'une nouvelle fiche produit