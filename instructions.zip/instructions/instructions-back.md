# Instructions

## Objectifs
Réaliser une partie de l'administration 'un site marchand en matériel informatique / électronique en utilisant exclusivement Bootsrap en version 4.5

Il y a trois pages à réaliser
- La page de gestion des produits (products.html)
- La page correspondant à la fiche produit du front (product-1.html)
- La page de création d'une nouvelle fiche produit (product-empty.html)

Ces pages sont à réaliser en HTML mais seront (ou devraient être) converties en PHP dans leur version finale plus tard.

## Liens et intéractions

En cliquant sur l'avatar et le nom de l'utilisateur en haut à droite, on ouvre un menu avec les items suivants:
- mon compte
- Déconnexion

En cliquant sur le lien Gestion des produits on arrive sur la page products.html

En cliquant sur le bouton "Modifier" du premier article de la listes des produits, on arrive sur la page product-1.html

En cliquant sur le bouton "Ajouter un produit" au dessus de la listes des produits, on arrive sur la page product-empty.html

En cliquant sur les boutons "Retirer", on ouvre une fenetre modale de confirmation. 